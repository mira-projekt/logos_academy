// завдання 1

// let city = 'Київ';
// city = 'Lviv';
// console.log(city);

// let address = city;
// alert(address);

// завдання 2

// let n = 10;
// let result = n ** 3;
// console.log(result);

// завдання 3
let pen = 4;
let pencil = 6;
let pricePen = 5.25;
let pricePencil = 3.50;
let result = pen * pricePen + pencil * pricePencil;
document.write('Загальна вартість:' + " " + result + " " + 'грн.');

