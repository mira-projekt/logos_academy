/* eslint-disable import/extensions */
import ru from './ru.js';
import en from './en.js';

export default { ru, en };
