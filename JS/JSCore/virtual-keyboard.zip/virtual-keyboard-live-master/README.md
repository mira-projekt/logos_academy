# virtual-keyboard-live

Live coding project repo for followed videos on YT:

part 1 https://www.youtube.com/watch?v=nuQW_cBLR6Q&t=53s 

part 2 https://www.youtube.com/watch?v=dAxI351AhCg&t=16s

---

Need simple implementation? Use my npm-package https://www.npmjs.com/package/rss-virtual-keyboard
